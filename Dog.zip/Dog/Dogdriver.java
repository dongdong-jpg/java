package Dog;

public class Dogdriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Dog	dog1=new Dog("xiaohong","red",12);
			dog1.print();
	}

}
