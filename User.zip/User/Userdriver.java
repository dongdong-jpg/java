package User;

public class Userdriver {

	public static void main(String[] args) {
		User user1=new User();
		user1.setUserName("dongdong");
		user1.setKouling("12345");
		user1.print();
		User user2 = new User("xixi");
		user2.print();
		User user3 = new User("beibei","123456");
		user3.print();
		

	}

}
