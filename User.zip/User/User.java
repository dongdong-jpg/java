package User;

	public class User {
	public String userName;
	public String kouling;
	public int num;
	public User() {
		
	}
	public User(String userName) {
		this.userName=userName;
	}
	public User(String userName,String kouling) {
		this.kouling=kouling;
		this.userName=userName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getKouling() {
		return kouling;
	}
	public void setKouling(String kouling) {
		this.kouling = kouling;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public void print() {
		System.out.println("userName:"+userName);
		System.out.println("kouling:"+kouling);
	}
}
