package Subject;

public class StudentList {
	private Student[] list;
	private int count;
	private int maxize;
	public StudentList(int maxsize){
		list = new Student[maxsize];
		this.maxize=maxize;
		count = 0;
	} 
	public boolean add(Student student) {
		if(student==null)
			return false;
		if(list.length<=count)
			return false;
		list[count]=student;
		count++;
		return true;
	}
	public int found(Student student) {
		for(int i=0;i<list.length&&student!=null;i++) {
			if(list[i]==student)
				return i;
		}
		return -1;		
	}
	public boolean remove(int index) {
		if(index>count||index<0)
			return false;
		list[count]=null;
		for(int i=index;i<count;i++) {
			list[i]=list[i+1];
			count--;
			list[count]=null;
		}
		return true;
	}
	public Student get(int index) {
		return list[index];
	}
	public int indexOf(String id) {
		for(int i=0;i<list.length&&list[i]!=null;i++) {
			if(list[i].getId()==id)
				return i;
		}
		return -1;
	}
	public int found(String name) {
		for(int i=0;i<list.length&&list[i]!=null;i++)
		{
			if(list[i].name==name)
				return i;
			}
		return -1;
	} 
	public String toString() {
		String info="";
		for(int i=0;i<list.length&&list[i]!=null;i++) {
			info+=list[i].toString();
		}
		return info;
	}
}